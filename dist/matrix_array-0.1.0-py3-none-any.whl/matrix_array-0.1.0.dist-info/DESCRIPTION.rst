
PyMatrix is for easier multi-Dimension matrix manipulation iterface. 
It provide basic Matrix utilities and vector based operator for easy access and compute elements. 
PyMatrix will act as glue between pure mathmatical interface and fast numpy computation core. You deem vector as row or col vector. 
With this interface your life will be easier. This is originally designed in 2014 when I am not satisfied with numpy, pandas and so on.
Use them altogether, you will find more about the package. 


